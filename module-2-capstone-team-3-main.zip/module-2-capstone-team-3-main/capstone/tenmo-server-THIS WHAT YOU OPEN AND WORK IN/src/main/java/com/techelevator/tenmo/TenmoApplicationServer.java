package com.techelevator.tenmo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenmoApplicationServer {

    public static void main(String[] args) {
        SpringApplication.run(TenmoApplicationServer.class, args);
    }

}
